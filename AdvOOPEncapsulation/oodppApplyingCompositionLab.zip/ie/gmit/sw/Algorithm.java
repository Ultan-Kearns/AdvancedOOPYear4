package ie.gmit.sw;

public enum Algorithm {
	RSA, DES, AES, CAESAR, VIGENERE; 
}
